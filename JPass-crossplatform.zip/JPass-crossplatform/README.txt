JPass — Fun “Locker” for macOS & Windows
=======================================

Default password: Admin1!
This is a convenience gate (not encryption). An error message appears on wrong passwords.

What you get
------------
- macOS:  macos/JPass.app (launcher), macos/jpass.sh (script), macos/media/
- Windows: windows/JPass.cmd (double-click), windows/JPass.ps1 (script), windows/media/
- On first unlock, the hidden folder auto-drops: readme.txt and Treasure.txt

How to use — Windows
--------------------
1) Right-click the ZIP → “Extract All…”, then open the extracted **JPass-crossplatform\windows** folder.
2) Double-click **JPass.cmd**.
   • If SmartScreen appears: click **More info** → **Run anyway**.
3) In the black window, type **Admin1!** and press **Enter** to UNLOCK.
   ✔ SUCCESS → your hidden folder opens:  %USERPROFILE%\JPass.data  
   ❌ WRONG PASSWORD → error message; try again.
4) When you’re done, go back to the same console, type **Admin1!** again and press **Enter** to **LOCK** (rehide).

How to use — macOS
------------------
1) Open **macos** and double-click **setup.sh** once to install the app to `~/Applications` and set up files.
   • If macOS warns it’s from an unidentified developer: **Right-click → Open → Open**.
2) In your Home folder, double-click **JPass** (it launches Terminal).
3) Type **Admin1!** + **Return** to UNLOCK. Finder reveals `~/JPass.data`.
4) When you’re done, click the Terminal window and type **Admin1!** again + **Return** to **LOCK** (rehide).

Change the password
-------------------
macOS:
  1) Compute a new SHA-256:  `printf "NEWPASS" | shasum -a 256 | awk '{print $1}'`
  2) Edit `~/jpass.sh`, replace the value in:  `PASSWORD_HASH="..."`.
  3) Save. Next run uses the new password.

Windows:
  1) Edit `windows\JPass.ps1`.
  2) Change the line:  `$Password = "Admin1!"`  → your new password.
  3) Save. Next run uses the new password.

Uninstall
---------
macOS: `rm -rf ~/Applications/JPass.app ~/JPass; rm ~/jpass.sh; chflags nohidden ~/JPass.data`
Windows: delete the extracted `windows` folder and (optionally) `%USERPROFILE%\JPass.data`.

Troubleshooting
---------------
- If nothing happens on macOS, run `macos/setup.sh` first, then use the **JPass** shortcut in your Home folder.
- Windows SmartScreen/AV prompts are expected for local scripts; choose “Run anyway/Allow”.
- The folder will not auto-hide; it only hides when you type the password again in the same console.
