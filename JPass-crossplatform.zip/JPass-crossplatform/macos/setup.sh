#!/bin/zsh
set -euo pipefail
DEST="$HOME/Applications/JPass.app"
[ -d "$HOME/Applications" ] || mkdir -p "$HOME/Applications"
cp -R "./JPass.app" "$DEST"
cp "./jpass.sh" "$HOME/jpass.sh"; chmod +x "$HOME/jpass.sh"
mkdir -p "$HOME/JPass.data"; chflags hidden "$HOME/JPass.data" 2>/dev/null || true
ln -sfn "$DEST" "$HOME/JPass"
echo "Installed. Double-click ~/JPass. Unlock with password, then enter it again in Terminal to lock."
