#!/bin/zsh
clear; stty -echo; trap 'stty echo' EXIT

TARGET_DIR="$HOME/JPass.data"
PASSWORD_HASH="26c749aae4e749de56d43c872cf9ec0ebcbf9040853431b08bc134e713fe26e1"  # SHA-256 of "Admin1!"
MP3_PACKAGED="$PWD/media/error_sound.mp3"
MP3_HOME1="$HOME/Jpass/error_sound.mp3"
MP3_HOME2="$HOME/Jpass/dennis_nedry_ahahah.mp3"
MP3=""
for p in "$MP3_PACKAGED" "$MP3_HOME1" "$MP3_HOME2"; do [ -f "$p" ] && MP3="$p" && break; done

[ -d "$TARGET_DIR" ] || mkdir -p "$TARGET_DIR"
chflags hidden "$TARGET_DIR" 2>/dev/null || true

# Drop readme + Treasure once (inside hidden folder)
[ -f "$TARGET_DIR/readme.txt" ] || cat > "$TARGET_DIR/readme.txt" <<'TXT'
Welcome to JPass! Unlock with the password, then when you're finished,
type the SAME password again in this Terminal window to LOCK (hide) the folder.
This is convenience, not encryption.
TXT

[ -f "$TARGET_DIR/Treasure.txt" ] || cat > "$TARGET_DIR/Treasure.txt" <<'TXT'
\033[43m\033[1;32m\033[1m   T R E A S U R E   \033[0m

You found the treasure!
Unlock with the password; lock again by entering the SAME password back here.
TXT

# UNLOCK
while true; do
  IFS= read -r -s PW || PW=""
  H=$(printf "%s" "$PW" | /usr/bin/shasum -a 256 | awk '{print $1}')
  if [[ "$H" == "$PASSWORD_HASH" ]]; then
    printf "\n\033[32mSUCCESS\033[0m\n"
    chflags nohidden "$TARGET_DIR" 2>/dev/null || true
    /usr/bin/osascript -e 'tell application "Finder" to reveal POSIX file "'"$TARGET_DIR"'"' >/dev/null
    /usr/bin/osascript -e 'tell application "Finder" to activate' >/dev/null
    break
  else
    printf "\n\033[31mWRONG PASSWORD\033[0m\n"
    [ -n "$MP3" ] && /usr/bin/afplay "$MP3" >/dev/null 2>&1 &
  fi
done

# LOCK (explicit)
printf "\n\033[2mType password again to \033[1mLOCK\033[0m\033[2m and hide the folder, then press Return.\033[0m\n"
while true; do
  IFS= read -r -s PW2 || PW2=""
  H2=$(printf "%s" "$PW2" | /usr/bin/shasum -a 256 | awk '{print $1}')
  if [[ "$H2" == "$PASSWORD_HASH" ]]; then
    chflags hidden "$TARGET_DIR" 2>/dev/null || true
    printf "\n\033[32mLocked. Goodbye.\033[0m\n"
    /usr/bin/osascript -e 'tell application "Terminal" to if (count of windows) > 0 then close front window' >/dev/null
    exit 0
  else
    printf "\n\033[31mWRONG PASSWORD (for lock)\033[0m\n"
    [ -n "$MP3" ] && /usr/bin/afplay "$MP3" >/dev/null 2>&1 &
    printf "\n"
  fi
done
