$Host.UI.RawUI.WindowTitle = "JPass"
[Console]::CursorVisible = $true
$TargetDir = Join-Path $env:USERPROFILE "JPass.data"
$PackMp3  = Join-Path $PSScriptRoot "media\error_sound.mp3"
$HomeMp3A = Join-Path $env:USERPROFILE "Jpass\error_sound.mp3"
$HomeMp3B = Join-Path $env:USERPROFILE "Jpass\dennis_nedry_ahahah.mp3"
$Mp3 = $null; foreach($p in @($PackMp3,$HomeMp3A,$HomeMp3B)){ if(Test-Path $p){ $Mp3=$p; break } }
$Password = "Admin1!"
if (-not (Test-Path $TargetDir)) { New-Item -ItemType Directory -Path $TargetDir | Out-Null }
attrib +h "$TargetDir" | Out-Null

# Drop readme/treasure once
$readme = Join-Path $TargetDir "readme.txt"
if (-not (Test-Path $readme)) {
@"
Welcome to JPass! Unlock with the password, then when you're finished,
type the SAME password again in this window to LOCK (hide) the folder.
"@ | Set-Content -NoNewline $readme -Encoding UTF8
}
$treasure = Join-Path $TargetDir "Treasure.txt"
if (-not (Test-Path $treasure)) {
@"
[43m[1;32m[1m   T R E A S U R E   [0m

You found the treasure!
Unlock with the password; lock again by entering the SAME password here.
"@ | Set-Content -NoNewline $treasure -Encoding UTF8
}

function Play-Mp3([string]$Path){
  if(Test-Path $Path){
    Add-Type -AssemblyName PresentationCore
    $p = New-Object System.Windows.Media.MediaPlayer
    $p.Open([Uri]::new((Resolve-Path $Path))); $p.Volume=1; $p.Play(); Start-Sleep -Milliseconds 1500
  }
}
function Read-PasswordLine{
  $l=""; while($true){ $k=[Console]::ReadKey($true)
    if($k.Key -eq "Enter"){ break } elseif($k.Key -eq "Escape"){ return $null } else { $l += $k.KeyChar } }
  return $l
}

# UNLOCK
while($true){
  $pw=Read-PasswordLine
  if($pw -eq $Password){
    Write-Host "`nSUCCESS" -ForegroundColor Green
    Start-Sleep -Milliseconds 400
    attrib -h "$TargetDir" | Out-Null
    Start-Process explorer.exe $TargetDir
    break
  } else {
    Write-Host "`nWRONG PASSWORD" -ForegroundColor Red
    if($Mp3){ Play-Mp3 $Mp3 }
  }
}

# LOCK (explicit)
Write-Host "`nType password again to LOCK and hide the folder, then press Enter." -ForegroundColor DarkGray
while($true){
  $pw2=Read-PasswordLine
  if($pw2 -eq $Password){
    attrib +h "$TargetDir" | Out-Null
    Write-Host "`nLocked. You can close this window." -ForegroundColor Green
    break
  } else {
    Write-Host "`nWRONG PASSWORD (for lock)" -ForegroundColor Red
    if($Mp3){ Play-Mp3 $Mp3 }
  }
}
